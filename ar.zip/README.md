# R-Launcher

StarCraft Remastered 네트워크 패킷 모니터링 및 학습용 프로젝트입니다.

## Features

- 네트워크 패킷 모니터링 (Winsock 함수 후킹)
- 방 정보 및 유저 목록 추적
- 블랙리스트 관리

## Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Backend**: Tauri (Rust)
- **DLL**: Rust (MinHook)

## Recommended IDE Setup

- [VS Code](https://code.visualstudio.com/) + [Tauri](https://marketplace.visualstudio.com/items?itemName=tauri-apps.tauri-vscode) + [rust-analyzer](https://marketplace.visualstudio.com/items?itemName=rust-lang.rust-analyzer)

## Disclaimer / 면책 조항

이 프로젝트는 **교육 및 연구 목적**으로만 제공됩니다.

- 이 코드를 실제 게임에서 사용하면 Blizzard Entertainment의 서비스 약관을 위반할 수 있으며, 계정 제재를 받을 수 있습니다.
- 저자는 이 코드의 사용으로 인한 어떠한 결과에 대해서도 책임지지 않습니다.
- 상업적 사용 또는 악의적 사용을 금지합니다.

This project is provided for **educational and research purposes only**.

- Using this code in actual games may violate Blizzard Entertainment's Terms of Service and may result in account sanctions.
- The author is not responsible for any consequences resulting from the use of this code.
- Commercial or malicious use is prohibited.
