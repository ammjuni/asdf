# 스타크래프트 프로세스 확인 스크립트
Write-Host "=== 스타크래프트 프로세스 검색 ===" -ForegroundColor Cyan
Write-Host ""

# 여러 가능한 이름으로 검색
$possibleNames = @("star", "scr", "StarCraft", "SCR", "brood")

foreach ($name in $possibleNames) {
    $processes = Get-Process | Where-Object { $_.ProcessName -like "*$name*" }
    if ($processes) {
        Write-Host "[$name] 검색 결과:" -ForegroundColor Yellow
        $processes | ForEach-Object {
            Write-Host "  - $($_.ProcessName) (PID: $($_.Id))" -ForegroundColor Green
        }
    }
}

Write-Host ""
Write-Host "=== Battle.net 프로세스 ===" -ForegroundColor Cyan
Get-Process | Where-Object { $_.ProcessName -like "*battle*" } | ForEach-Object {
    Write-Host "  - $($_.ProcessName) (PID: $($_.Id))" -ForegroundColor Magenta
}

Write-Host ""
Write-Host "스타크래프트를 실행한 후 이 스크립트를 다시 실행해보세요." -ForegroundColor Yellow
