import { motion } from "framer-motion";
import { Ban, Signal, SignalLow, SignalMedium, SignalHigh, Users, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export interface RoomUser {
  nickname: string;
  battletag: string;
  playerId?: number;
  ipAddress: string;
  port?: number;
}

interface UserListTableProps {
  slots: string[];
  packetUsers: RoomUser[];
  getPing: (ipAddress: string) => number | null;
  isInBlacklist: (battletag: string) => boolean;
  onAddToBlacklist: (user: RoomUser) => void;
  onDrop: (index: number) => void;
}

const getPingColor = (ping: number) => {
  if (ping < 50) return "text-success";
  if (ping < 100) return "text-accent";
  if (ping < 150) return "text-warning";
  return "text-destructive";
};

const PingIndicator = ({ ping }: { ping: number | null }) => {
  if (ping === null) return <span className="text-muted-foreground">-</span>;
  const color = getPingColor(ping);
  if (ping < 50) return <SignalHigh className={`h-4 w-4 ${color}`} />;
  if (ping < 100) return <SignalMedium className={`h-4 w-4 ${color}`} />;
  if (ping < 150) return <SignalLow className={`h-4 w-4 ${color}`} />;
  return <Signal className={`h-4 w-4 ${color}`} />;
};

export function UserListTable({
  slots,
  packetUsers,
  getPing,
  isInBlacklist,
  onAddToBlacklist,
  onDrop,
}: UserListTableProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1 }}
      className="rounded-lg border border-border/50 overflow-hidden"
    >
      <div className="px-5 py-4 border-b border-border/50 flex items-center gap-3 bg-secondary/30">
        <Users className="h-4 w-4 text-primary" />
        <h3 className="font-display text-base font-semibold text-foreground">유저 목록</h3>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-border/50">
              <TableHead className="text-center w-12">#</TableHead>
              <TableHead>닉네임</TableHead>
              <TableHead>배틀태그</TableHead>
              <TableHead className="text-center">핑</TableHead>
              <TableHead className="text-right">액션</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {slots.map((nickname, index) => {
              const user = packetUsers.find(u => u.nickname === nickname);
              const ping = user ? getPing(user.ipAddress) : null;
              const isBanned = user ? isInBlacklist(user.battletag) : false;

              return (
                <TableRow key={index} className={nickname ? "border-border/30" : "border-border/30 opacity-30"}>
                  <TableCell className="text-center font-mono text-xs font-semibold">{index}</TableCell>
                  <TableCell className="font-medium text-foreground">
                    {nickname || <span className="text-muted-foreground italic">(빈 슬롯)</span>}
                  </TableCell>
                  <TableCell className="font-mono text-sm text-primary">
                    {user?.battletag || (nickname ? "검증 중..." : "-")}
                  </TableCell>
                  <TableCell className="text-center">
                    {user && (
                      <div className="flex items-center justify-center gap-2">
                        <PingIndicator ping={ping} />
                        {ping !== null && (
                          <span className={`text-xs font-semibold ${getPingColor(ping)}`}>{ping}ms</span>
                        )}
                      </div>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    {nickname && (
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="!border-orange-400 !text-orange-400 hover:!bg-orange-500/20 font-bold"
                          onClick={() => onDrop(index)}
                        >
                          <Zap className="h-4 w-4 mr-1" />
                          드랍
                        </Button>

                        {user &&
                          (isBanned ? (
                            <Badge variant="destructive" className="text-xs">
                              차단됨
                            </Badge>
                          ) : (
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-destructive border-destructive/50 hover:text-destructive hover:bg-destructive/10"
                              onClick={() => onAddToBlacklist(user)}
                            >
                              <Ban className="h-4 w-4 mr-1" />
                              차단
                            </Button>
                          ))}
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </motion.div>
  );
}
