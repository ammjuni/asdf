import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export interface RoomUser {
  nickname: string;
  battletag: string;
  playerId?: number;
  ipAddress: string;
  port?: number;
}

interface UserListTableProps {
  slots: string[];
  users: RoomUser[];
  onDrop: (index: number) => void;
}

export function UserListTable({ slots, users, onDrop }: UserListTableProps) {
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[50px] text-center">#</TableHead>
            <TableHead>닉네임 (메모리)</TableHead>
            <TableHead>배틀태그 (패킷)</TableHead>
            <TableHead>IP 주소</TableHead>
            <TableHead className="text-right">관리</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {slots.map((nickname, index) => {
            // [핵심] 메모리 이름과 일치하는 패킷 데이터 찾기
            const packetData = users.find(u => u.nickname === nickname);

            return (
              <TableRow key={index} className={nickname ? "" : "opacity-40"}>
                <TableCell className="text-center font-mono">{index}</TableCell>
                <TableCell className="font-medium">
                  {nickname || <span className="text-muted-foreground italic">빈 슬롯</span>}
                </TableCell>
                <TableCell className="text-blue-500">
                  {packetData?.battletag || (nickname ? "검증 중..." : "-")}
                </TableCell>
                <TableCell className="font-mono text-xs">
                  {packetData?.ipAddress || "-"}
                </TableCell>
                <TableCell className="text-right">
                  {nickname && (
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={() => onDrop(index)}
                    >
                      강퇴
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
