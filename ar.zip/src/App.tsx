import { useState, useEffect, useRef } from "react";
import { invoke } from "@tauri-apps/api/core";
import { motion } from "framer-motion";
import { Settings, Power, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ConnectionChip } from "@/components/ConnectionChip";
import { RoomInfoCard } from "@/components/RoomInfoCard";
import { UserListTable, type RoomUser } from "@/components/UserListTable";
import { BlacklistPanel, type BlacklistEntry } from "@/components/BlacklistPanel";
import { AddBlacklistDialog } from "@/components/AddBlacklistDialog";
import { RoomHistoryPanel, type RoomHistoryEntry } from "@/components/RoomHistoryPanel";

interface RoomInfo {
  inRoom: boolean;
  roomId?: string;
  roomName: string;
  mapName: string;
  hostName?: string;
  forceNames?: string[];
}

interface PeerLatency {
  ip_address: string;
  port: number;
  ping_ms: number;
  avg_ping_ms: number;
  sample_count: number;
}

function App() {
  const [roomSlots, setRoomSlots] = useState<string[]>(Array(12).fill(""));
  const [roomUsers, setRoomUsers] = useState<RoomUser[]>([]);
  const [blacklist, setBlacklist] = useState<BlacklistEntry[]>([]);
  const [roomInfo, setRoomInfo] = useState<RoomInfo>({ inRoom: false, roomName: "", mapName: "" });
  const [isDllInjected, setIsDllInjected] = useState(false);
  const [starcraftPid, setStarcraftPid] = useState<number | null>(null);
  const [isInjecting, setIsInjecting] = useState(false);
  const [injectStatus, setInjectStatus] = useState<string>("");
  const [autoInject, setAutoInject] = useState(false);
  const [selectedUser, setSelectedUser] = useState<RoomUser | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [roomHistory, setRoomHistory] = useState<RoomHistoryEntry[]>([]);
  const [peerLatencies, setPeerLatencies] = useState<PeerLatency[]>([]);
  const lastInjectedPidRef = useRef<number | null>(null);

  const getPingForUser = (ipAddress: string): number | null => {
    const latency = peerLatencies.find(p => p.ip_address === ipAddress);
    return latency ? latency.ping_ms : null;
  };

  // [수정] 데이터 통합 수집 로직
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const [slots, users, latencies] = await Promise.all([
          invoke<string[]>("get_room_slots"),
          invoke<RoomUser[]>("get_room_users"),
          invoke<PeerLatency[]>("get_peer_latencies")
        ]);
        setRoomSlots(slots);
        setRoomUsers(users);
        setPeerLatencies(latencies);
      } catch (err) {
        console.error("데이터 동기화 실패:", err);
      }
    }, 100);
    return () => clearInterval(interval);
  }, []);

  // 초기 데이터 및 기타 정보 로드
  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const [list, info, pid] = await Promise.all([
          invoke<BlacklistEntry[]>("get_blacklist"),
          invoke<RoomInfo>("get_room_info"),
          invoke<number | null>("find_starcraft_process"),
        ]);
        setBlacklist(list);
        setRoomInfo(info);
        setStarcraftPid(pid);
      } catch (err) {
        console.error("초기 데이터 로드 실패:", err);
      }
    };
    
    loadInitialData();
    
    // 프로세스 및 DLL 상태 주기적 확인
    const interval = setInterval(async () => {
      try {
        const [pid, injected] = await Promise.all([
          invoke<number | null>("find_starcraft_process"),
          invoke<boolean>("is_dll_injected"),
        ]);
        setStarcraftPid(pid);
        setIsDllInjected(injected);
      } catch (err) {
        console.error("상태 확인 실패:", err);
      }
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);

  // Load history on mount
  useEffect(() => {
    const loadHistory = async () => {
      try {
        const history = await invoke<RoomHistoryEntry[]>("get_room_history");
        setRoomHistory(history);
      } catch (error) {
        console.error("Failed to load history:", error);
      }
    };
    loadHistory();
  }, []);

  // 자동 주입 로직 - 비활성화 (수동 버튼으로만 주입)
  // useEffect(() => {
  //   if (
  //     autoInject &&
  //     starcraftPid &&
  //     !isDllInjected &&
  //     !isInjecting &&
  //     lastInjectedPidRef.current !== starcraftPid
  //   ) {
  //     console.log(`[AUTO-INJECT] 자동 주입 시작 (PID: ${starcraftPid})`);
  //     handleInjectDll();
  //   }
  // }, [autoInject, starcraftPid, isDllInjected, isInjecting]);

  // [수정] 전투 기록 저장: 배틀태그가 있는(검증된) 유저만 기록
  useEffect(() => {
    if (roomInfo.inRoom && roomInfo.roomId && roomUsers.length > 0) {
      const validUsers = roomUsers.filter(u => u.battletag && u.battletag.trim() !== "");
      if (validUsers.length > 0) {
        invoke("add_room_history", { 
          entry: {
            timestamp: Date.now(),
            roomInfo,
            users: validUsers
          }
        }).catch(error => console.error("History save failed:", error));
      }
    }
  }, [roomUsers, roomInfo]);

  const handleDrop = async (index: number) => {
    try {
      await invoke("drop_player", { playerIndex: index });
      console.log(`[DROP] Slot ${index} drop command sent.`);
    } catch (err) {
      console.error("[DROP] Error:", err);
    }
  };

  const addToBlacklist = async (battletag: string, memo?: string) => {
    if (!battletag.trim()) return;
    try {
      await invoke("add_to_blacklist", { battletag: battletag.trim(), memo: memo || null });
      const list = await invoke<BlacklistEntry[]>("get_blacklist");
      setBlacklist(list);
    } catch (error) {
      console.error("Failed to add to blacklist:", error);
    }
  };

  const removeFromBlacklist = async (battletag: string) => {
    try {
      await invoke("remove_from_blacklist", { battletag });
      const list = await invoke<BlacklistEntry[]>("get_blacklist");
      setBlacklist(list);
    } catch (error) {
      console.error("Failed to remove from blacklist:", error);
    }
  };

  const updateMemo = async (battletag: string, memo: string) => {
    try {
      await invoke("update_blacklist_memo", { battletag, memo });
      const list = await invoke<BlacklistEntry[]>("get_blacklist");
      setBlacklist(list);
    } catch (error) {
      console.error("Failed to update memo:", error);
    }
  };

  const handleInjectDll = async () => {
    setIsInjecting(true);
    setInjectStatus("");
    try {
      const dllPath = await invoke<string>("get_default_dll_path");
      const result = await invoke<string>("inject_dll", { dllPath });
      setInjectStatus(result);

      if (result.includes("successfully") || result.includes("SUCCESS")) {
        setTimeout(async () => {
          const injected = await invoke<boolean>("is_dll_injected");
          setIsDllInjected(injected);
          if (injected && starcraftPid) {
            lastInjectedPidRef.current = starcraftPid;
          }
        }, 500);
      }
      setTimeout(() => setInjectStatus(""), 5000);
    } catch (error) {
      console.error("[INJECT] Error:", error);
      setInjectStatus(`Error: ${error}`);
    } finally {
      setIsInjecting(false);
    }
  };

  const isInBlacklist = (battletag: string) => {
    return blacklist.some(entry => entry.battletag === battletag);
  };

  const handleAddToBlacklist = (user: RoomUser) => {
    setSelectedUser(user);
    setDialogOpen(true);
  };

  const handleConfirmBlacklist = (battletag: string, memo: string) => {
    addToBlacklist(battletag, memo);
  };

  const handleClearHistory = async () => {
    try {
      await invoke("clear_room_history");
      setRoomHistory([]);
    } catch (error) {
      console.error("Failed to clear history:", error);
    }
  };

  const handleRemoveHistoryEntry = async (timestamp: number) => {
    try {
      await invoke("remove_room_history", { timestamp });
      const history = await invoke<RoomHistoryEntry[]>("get_room_history");
      setRoomHistory(history);
    } catch (error) {
      console.error("Failed to remove history entry:", error);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <motion.h1
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="font-display text-xl font-bold text-foreground"
              >
                <span className="text-glow-primary">SC</span>
                <span className="text-muted-foreground">:</span>
                <span className="text-accent">REMASTERED</span>
              </motion.h1>
              <ConnectionChip isConnected={isDllInjected} />
            </div>

            <div className="flex items-center gap-2">
              <Badge
                variant={starcraftPid ? "default" : "secondary"}
                className={starcraftPid ? "bg-success/20 text-success border-success/30" : ""}
              >
                <Power className="h-3 w-3 mr-1" />
                {starcraftPid ? `PID: ${starcraftPid}` : "스타 미실행"}
              </Badge>

              <Button
                variant={autoInject ? "default" : "outline"}
                size="sm"
                onClick={() => setAutoInject(!autoInject)}
                className={autoInject ? "bg-primary/20 text-primary border-primary/30" : ""}
              >
                <Zap className="h-4 w-4 mr-1" />
                자동
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={handleInjectDll}
                disabled={!starcraftPid || isInjecting || isDllInjected}
              >
                {isInjecting ? "주입 중..." : "주입"}
              </Button>

              <Button
                variant="ghost"
                size="icon"
                className="text-muted-foreground hover:text-foreground"
              >
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {injectStatus && (
            <motion.p
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`text-xs mt-2 ${
                injectStatus.includes("Error") || injectStatus.includes("failed")
                  ? "text-destructive"
                  : "text-success"
              }`}
            >
              {injectStatus}
            </motion.p>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <RoomInfoCard roomInfo={roomInfo} />
            <UserListTable
              slots={roomSlots}
              packetUsers={roomUsers}
              getPing={getPingForUser}
              isInBlacklist={isInBlacklist}
              onAddToBlacklist={handleAddToBlacklist}
              onDrop={handleDrop}
            />
            <RoomHistoryPanel
              history={roomHistory}
              onClearHistory={handleClearHistory}
              onRemoveEntry={handleRemoveHistoryEntry}
              onAddToBlacklist={addToBlacklist}
              isInBlacklist={isInBlacklist}
            />
          </div>

          <div className="lg:col-span-1">
            <BlacklistPanel
              entries={blacklist}
              onRemove={removeFromBlacklist}
              onUpdateMemo={updateMemo}
              onAddEntry={addToBlacklist}
            />
          </div>
        </div>
      </main>

      <AddBlacklistDialog
        user={selectedUser}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onConfirm={handleConfirmBlacklist}
      />
    </div>
  );
}

export default App;
